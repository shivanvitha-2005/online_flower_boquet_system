/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package online.flower.boque.system;

/**
 *
 * @author hp
 */
public class Global {
    public static String  MAIL;
    public static String  USERNAME;
    public static MainPage MAINPAGE;
    public static Orders ORDERSPAGE;
    public static int ADDRESSID ;
    public static int CARDID ;
    public static int ORDERS_ORDERSID;
    public static String ORDERS_DATE;
    public static int ORDERS_ADDRESSID;
    public static int ORDERS_CARDID;
    

    public static void signOut(){
        MAIL=null;
        USERNAME=null;
        MAINPAGE=null;
        ADDRESSID=0;
        CARDID=0;
        ORDERS_ORDERSID=0;
        ORDERS_ADDRESSID=0;
        ORDERS_CARDID=0;
    }
}
