/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package online.flower.boque.system;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.swing.*;

/**
 *
 * @author hp
 */
public class SendMail {
    public static boolean SendMail(String to,String sub,String msg){
        String host="smtp.gmail.com";
        final String user="floral.house.swing@gmail.com";
        final String password="Swing@2005";

        //Get the session object
        Properties props = new Properties();
        props.put("mail.smtp.host",host);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable","true");

        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(user,password);
                    }
                });

       
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(user));
            message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
            message.setSubject(sub);
            message.setText(msg);

            //send the message
            Transport.send(message);

            System.out.println("message sent successfully...");
            return true;

        } catch (MessagingException e) {
            System.err.println(e);
            return false;
        }
    }
        
    
    public static int getOTP(){
    int max=9999;
    int min=1000;
    int OTP = (int)(Math.random() * (max - min + 1) + min) ; 
    return OTP;
    } 
    
    public static boolean verifyOTP(JPanel obj,String mail,int OTP){
        String val=JOptionPane.showInputDialog(obj, "Enter the OTP sent to "+mail);
            try{
                int enteredOTP=Integer.parseInt(val);
                if(enteredOTP==OTP)
                    return true;
                else
                    JOptionPane.showMessageDialog(obj, "Wrong OTP Entered");
                return false;
            }
            catch(NumberFormatException e){
                JOptionPane.showMessageDialog(obj, "OTP must be Numeric");
                return false;
            }
    }
}
