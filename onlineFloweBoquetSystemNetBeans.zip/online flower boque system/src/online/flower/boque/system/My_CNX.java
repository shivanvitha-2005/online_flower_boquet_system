
package online.flower.boque.system;
import java.sql.Connection;
import java.sql.*;

public class My_CNX {
    public static String USERNAME="root";
    public static String PASSWORD="root";
    public static String CON_URL="jdbc:mysql://localhost:3306/floralHouseDB?zeroDateTimeBehavior=CONVERT_TO_NULL";
            
    public static Connection getConnection(){
       Connection con = null;
       
        try{
        
        con = DriverManager.getConnection(CON_URL,USERNAME,PASSWORD);
        System.out.println("Connected");
        }
        catch(SQLException e){
           System.err.println(e);
           System.out.println("Not Connected");
        }
        
        return con;
        
    }
}
